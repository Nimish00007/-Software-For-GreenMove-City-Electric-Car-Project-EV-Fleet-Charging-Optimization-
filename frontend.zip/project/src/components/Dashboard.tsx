import React from 'react';
import { Sidebar } from './Sidebar';
import { MapView } from './MapView';
import { useWebSocket } from '../hooks/useWebSocket';

export const Dashboard: React.FC = () => {
  const { data, connected } = useWebSocket(
    import.meta.env.VITE_WEBSOCKET_URL || 'ws://127.0.0.1:8000/ws/fleet'
  );

  // Mock data for development/demo purposes when WebSocket is not connected
  const mockData = {
    evs: [
      { id: "UNO", battery: 85, lat: 40.7128, lon: -74.0060, assigned_station: "Station-A" },
      { id: "DUO-Y", battery: 15, lat: 40.7138, lon: -74.0050, assigned_station: null },
      { id: "TRIO-Z", battery: 42, lat: 40.7118, lon: -74.0070, assigned_station: "Station-B" },
      { id: "QUATTRO", battery: 78, lat: 40.7148, lon: -74.0040, assigned_station: null },
    ],
    stations: [
      { id: "Station-A", lat: 40.7140, lon: -74.0055, capacity: 2, occupied: 1 },
      { id: "Station-B", lat: 40.7125, lon: -74.0065, capacity: 3, occupied: 1 },
      { id: "Station-C", lat: 40.7135, lon: -74.0045, capacity: 1, occupied: 0 },
    ]
  };

  const fleetData = data || mockData;

  return (
    <div className="h-screen flex bg-gray-100">
      <Sidebar 
        evs={fleetData.evs} 
        stations={fleetData.stations} 
        connected={connected}
      />
      <MapView 
        evs={fleetData.evs} 
        stations={fleetData.stations}
      />
    </div>
  );
};