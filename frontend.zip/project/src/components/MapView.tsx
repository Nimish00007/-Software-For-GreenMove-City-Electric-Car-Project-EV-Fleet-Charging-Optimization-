import React, { useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L, { Icon } from 'leaflet';
import { EV, Station } from '../types/fleet';

// Fix for default markers
import 'leaflet/dist/leaflet.css';

// Fix for default markers in Webpack
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

// Custom icons
const createEVIcon = (battery: number) => {
  const color = battery < 20 ? 'red' : battery <= 50 ? 'orange' : 'green';
  return new Icon({
    iconUrl: 'https://cdn-icons-png.flaticon.com/512/3103/3103459.png',
    iconSize: [32, 32],
    iconAnchor: [16, 32],
    popupAnchor: [0, -32],
    className: `ev-marker-${color}`,
  });
};

const stationIcon = new Icon({
  iconUrl: 'https://cdn-icons-png.flaticon.com/512/1049/1049443.png',
  iconSize: [28, 28],
  iconAnchor: [14, 28],
  popupAnchor: [0, -28],
});

interface MapViewProps {
  evs: EV[];
  stations: Station[];
}

// Component to update map view when data changes
const MapUpdater: React.FC<{ evs: EV[]; stations: Station[] }> = ({ evs, stations }) => {
  const map = useMap();

  useEffect(() => {
    if (evs.length > 0 || stations.length > 0) {
      const allPoints = [
        ...evs.map(ev => [ev.lat, ev.lon] as [number, number]),
        ...stations.map(station => [station.lat, station.lon] as [number, number])
      ];

      if (allPoints.length > 0) {
        const group = new L.featureGroup(allPoints.map(point => L.marker(point)));
        map.fitBounds(group.getBounds().pad(0.1));
      }
    }
  }, [map, evs, stations]);

  return null;
};

export const MapView: React.FC<MapViewProps> = ({ evs, stations }) => {
  // Calculate polylines for EVs assigned to stations
  const polylines = useMemo(() => {
    const lines: Array<{ positions: [number, number][]; color: string }> = [];
    
    evs.forEach(ev => {
      if (ev.assigned_station) {
        const station = stations.find(s => s.id === ev.assigned_station);
        if (station) {
          const color = ev.battery < 20 ? '#ef4444' : ev.battery <= 50 ? '#f97316' : '#22c55e';
          lines.push({
            positions: [[ev.lat, ev.lon], [station.lat, station.lon]],
            color,
          });
        }
      }
    });
    
    return lines;
  }, [evs, stations]);

  const getBatteryColor = (battery: number) => {
    if (battery < 20) return 'text-red-500';
    if (battery <= 50) return 'text-orange-500';
    return 'text-green-500';
  };

  return (
    <div className="flex-1 relative">
      <MapContainer
        center={[40.7128, -74.0060]} // Default to NYC
        zoom={13}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        
        <MapUpdater evs={evs} stations={stations} />
        
        {/* EV Markers */}
        {evs.map((ev) => (
          <Marker
            key={ev.id}
            position={[ev.lat, ev.lon]}
            icon={createEVIcon(ev.battery)}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-semibold text-gray-800 mb-2">EV: {ev.id}</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600">Battery:</span>
                    <span className={`font-semibold ${getBatteryColor(ev.battery)}`}>
                      {ev.battery}%
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600">Station:</span>
                    <span className={ev.assigned_station ? 'text-green-600' : 'text-gray-500'}>
                      {ev.assigned_station || 'None'}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Lat: {ev.lat.toFixed(4)}, Lon: {ev.lon.toFixed(4)}
                  </div>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
        
        {/* Station Markers */}
        {stations.map((station) => (
          <Marker
            key={station.id}
            position={[station.lat, station.lon]}
            icon={stationIcon}
          >
            <Popup>
              <div className="p-2">
                <h3 className="font-semibold text-gray-800 mb-2">Station: {station.id}</h3>
                <div className="space-y-1 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600">Capacity:</span>
                    <span className="font-semibold">{station.capacity}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600">Occupied:</span>
                    <span className={`font-semibold ${station.occupied > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                      {station.occupied}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-600">Available:</span>
                    <span className="font-semibold text-blue-600">
                      {station.capacity - station.occupied}
                    </span>
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    Lat: {station.lat.toFixed(4)}, Lon: {station.lon.toFixed(4)}
                  </div>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
        
        {/* Polylines connecting EVs to their assigned stations */}
        {polylines.map((line, index) => (
          <Polyline
            key={index}
            positions={line.positions}
            pathOptions={{
              color: line.color,
              weight: 3,
              opacity: 0.8,
              dashArray: '5, 10',
            }}
          />
        ))}
      </MapContainer>
      
      {/* Map Legend */}
      <div className="absolute top-4 right-4 bg-white bg-opacity-95 backdrop-blur-sm rounded-lg shadow-lg p-4 z-10">
        <h4 className="font-semibold text-gray-800 mb-3 text-sm">Legend</h4>
        <div className="space-y-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full"></div>
            <span className="text-gray-700">Low Battery (&lt;20%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-orange-500 rounded-full"></div>
            <span className="text-gray-700">Medium Battery (20-50%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            <span className="text-gray-700">High Battery (&gt;50%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-1 bg-gray-400" style={{ borderStyle: 'dashed' }}></div>
            <span className="text-gray-700">EV-Station Connection</span>
          </div>
        </div>
      </div>
    </div>
  );
};