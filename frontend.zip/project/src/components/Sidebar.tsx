import React from 'react';
import { EV, Station } from '../types/fleet';
import { Battery, Zap, Car, Wifi, WifiOff } from 'lucide-react';

interface SidebarProps {
  evs: EV[];
  stations: Station[];
  connected: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ evs, stations, connected }) => {
  const getBatteryColor = (battery: number) => {
    if (battery < 20) return 'text-red-400';
    if (battery <= 50) return 'text-orange-400';
    return 'text-green-400';
  };

  const getBatteryIcon = (battery: number) => {
    const color = battery < 20 ? 'text-red-400' : battery <= 50 ? 'text-orange-400' : 'text-green-400';
    return <Battery className={`w-4 h-4 ${color}`} />;
  };

  const totalOccupied = stations.reduce((sum, station) => sum + station.occupied, 0);
  const totalCapacity = stations.reduce((sum, station) => sum + station.capacity, 0);

  return (
    <div className="w-80 bg-gray-900 text-gray-200 p-6 overflow-y-auto">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">EV Fleet Monitor</h1>
        <div className="flex items-center gap-2">
          {connected ? (
            <><Wifi className="w-4 h-4 text-green-400" /><span className="text-green-400 text-sm">Connected</span></>
          ) : (
            <><WifiOff className="w-4 h-4 text-red-400" /><span className="text-red-400 text-sm">Disconnected</span></>
          )}
        </div>
      </div>

      {/* Stats */}
      <div className="mb-8">
        <div className="grid grid-cols-1 gap-4">
          <div className="bg-gray-800 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <Car className="w-6 h-6 text-blue-400" />
              <div>
                <p className="text-gray-400 text-sm">Total EVs</p>
                <p className="text-2xl font-bold text-white">{evs.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <Zap className="w-6 h-6 text-yellow-400" />
              <div>
                <p className="text-gray-400 text-sm">Charging Stations</p>
                <p className="text-2xl font-bold text-white">{stations.length}</p>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                <span className="text-xs font-bold text-white">%</span>
              </div>
              <div>
                <p className="text-gray-400 text-sm">Station Utilization</p>
                <p className="text-2xl font-bold text-white">
                  {totalCapacity > 0 ? Math.round((totalOccupied / totalCapacity) * 100) : 0}%
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* EV Table */}
      <div>
        <h2 className="text-lg font-semibold text-white mb-4">Electric Vehicles</h2>
        <div className="bg-gray-800 rounded-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-700 text-gray-300 text-sm">
                  <th className="px-4 py-3 text-left">EV ID</th>
                  <th className="px-4 py-3 text-left">Battery</th>
                  <th className="px-4 py-3 text-left">Station</th>
                </tr>
              </thead>
              <tbody>
                {evs.map((ev, index) => (
                  <tr
                    key={ev.id}
                    className={`border-t border-gray-700 hover:bg-gray-700 transition-colors ${
                      index % 2 === 0 ? 'bg-gray-800' : 'bg-gray-750'
                    }`}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <Car className="w-4 h-4 text-gray-400" />
                        <span className="font-medium text-white">{ev.id}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        {getBatteryIcon(ev.battery)}
                        <span className={`font-semibold ${getBatteryColor(ev.battery)}`}>
                          {ev.battery}%
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={ev.assigned_station ? 'text-green-400' : 'text-gray-500'}>
                        {ev.assigned_station || 'None'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Stations Summary */}
      <div className="mt-8">
        <h2 className="text-lg font-semibold text-white mb-4">Charging Stations</h2>
        <div className="space-y-2">
          {stations.map((station) => (
            <div key={station.id} className="bg-gray-800 rounded-lg p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-400" />
                  <span className="font-medium text-white">{station.id}</span>
                </div>
                <div className="text-right">
                  <span className={`text-sm ${station.occupied > 0 ? 'text-orange-400' : 'text-green-400'}`}>
                    {station.occupied}/{station.capacity}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};