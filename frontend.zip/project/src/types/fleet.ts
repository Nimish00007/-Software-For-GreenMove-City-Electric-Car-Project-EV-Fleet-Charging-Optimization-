export interface EV {
  id: string;
  battery: number;
  lat: number;
  lon: number;
  assigned_station: string | null;
}

export interface Station {
  id: string;
  lat: number;
  lon: number;
  capacity: number;
  occupied: number;
}

export interface FleetData {
  evs: EV[];
  stations: Station[];
}